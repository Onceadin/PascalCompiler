#ifndef _MILAN_MILAN_H
#define _MILAN_MILAN_H

void milan_error(char const *);

#endif
